#pragma once
/**
 * Salin file ini menjadi `secrets.h` di folder yang sama, lalu isi kredensial lokal Anda.
 * File `secrets.h` di-ignore oleh Git dan tidak pernah di-commit.
 */

#define WIFI_SSID  "RafaHome"
#define WIFI_PASS  "bismilah"

#define MQTT_HOST  "192.168.10.250"
#define MQTT_PORT  1883
#define MQTT_USER  "shoto_bridge"
#define MQTT_PASS  "1qaz2wsx"

#define OTA_PASS   "1q2w3e4r"
